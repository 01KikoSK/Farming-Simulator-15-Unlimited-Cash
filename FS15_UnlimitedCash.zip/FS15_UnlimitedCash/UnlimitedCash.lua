UnlimitedCash = {};

function UnlimitedCash:loadMap(name)
    print("Unlimited Cash Mod loaded")
end;

function UnlimitedCash:keyEvent(unicode, sym, modifier, isDown)
    if isDown and (modifier == 2) and (sym == Input.KEY_m) then -- 2 = levý CTRL
        g_currentMission:addSharedMoney(1000000, "other")
        print("Přidáno 1 000 000 €!")
    end
end;

addModEventListener(UnlimitedCash);